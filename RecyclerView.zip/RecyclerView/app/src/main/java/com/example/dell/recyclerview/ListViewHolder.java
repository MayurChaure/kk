package com.example.dell.recyclerview;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dell.recyclerview.R;

public class ListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    View view;
    TextView textView2;
     TextView textView3;
     ImageView imageView;
     TextView textView4;
     TextView textView5;
      Button button;

    public ListViewHolder(View itemView) {
        super(itemView);
        view = itemView;
        textView2 = itemView.findViewById(R.id.textView2);
        textView3 = itemView.findViewById(R.id.textView3);
        imageView=itemView.findViewById(R.id.imageView2);
        textView4=itemView.findViewById(R.id.textView4);
        textView5=itemView.findViewById(R.id.textView5);
        button = itemView.findViewById(R.id.button);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Toast.makeText(view.getContext(),"Welcome to " +getAdapterPosition(),Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(view.getContext(),HomeActivity.class).putExtra("position",getAdapterPosition());
        view.getContext().startActivity(intent);
    }
}
