package com.example.dell.recyclerview;

public class Country {
  public String name;
  public String capitalName;
  public int flag;
  public String description;
  public String primeMinisterName;

   public Country(String name, String capitalName, int flag, String description, String primeMinisterName){
       this.name = name;
       this.capitalName = capitalName;
       this.flag = flag;
       this.description = description ;
       this.primeMinisterName = primeMinisterName;

   }
}
