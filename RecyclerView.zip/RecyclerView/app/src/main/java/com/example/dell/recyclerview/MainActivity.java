package com.example.dell.recyclerview;

import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
   List<Country> countries= new ArrayList <>();
    private static final String TAG = "ABC";
    ProductListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List values = null;

        RecyclerView recyclerView = findViewById(R.id.recyclerView5);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);


       /* List<String> countries = new ArrayList<>();
        countries.add("India");
        countries.add("USA");
        countries.add("Germany");
        countries.add("Pak");
        countries.add("Bangladesh");
        countries.add("Nepal");
        countries.add("Bhutan");
        countries.add("England");
        countries.add("Africa");
        countries.add("Syria");

        List<String> capital = new ArrayList<>();
        capital.add("Delhi");
        capital.add("Washington");
        capital.add("Berlin");
        capital.add("Islamabad");
        capital.add("Dhaka");
        capital.add("Katmandu");
        capital.add("Thimphu");
        capital.add("London");
        capital.add("Pretoria");
        capital.add("Damascus");


        List<Integer> images=new ArrayList<>();
        images.add(R.drawable.india);
        images.add(R.drawable.usa);
        images.add(R.drawable.germany);
        images.add(R.drawable.pak);
        images.add(R.drawable.bangladesh);
        images.add(R.drawable.nepal);
        images.add(R.drawable.bhutan);
        images.add(R.drawable.england);
        images.add(R.drawable.africa);
        images.add(R.drawable.syria);*/

        //List<Country> cc = new ArrayList<>();
       /* Country country1 = new Country("India","Delhi",R.drawable.india," Country with unity in differences","Narendra Modi");
        Country country2 = new Country("USA","Washington",R.drawable.usa,"Country having super power","Trump");
        Country country3 = new Country("Germany","Berlin",R.drawable.germany,"Country having largest industries","Markel");
        Country country4 = new Country("Pak","Islamabad",R.drawable.pak," Country having most terrible","Sharif");
        Country country5 = new Country("Bangladesh","Dhaka",R.drawable.bangladesh," A Country of southern Asia on the bay of bengal ","Sheikh Hasina");
        Country country6 = new Country("Nepal","katmandu",R.drawable.nepal,"Landlocked country in south asia","Prema khandu");
        Country country7 = new Country("Bhutan","Thimphu",R.drawable.bhutan,"Country with unity in differences","Tshering Tobgay");
        Country country8 = new Country("England","London",R.drawable.england,"Country with unity in differences","Theresasa may");
        Country country9 = new Country("Africa","Pretoria",R.drawable.africa,"Country with unity in differences","Louis Botha");
        Country country10 = new Country("Syria","Damascus",R.drawable.syria,"Country with unity in differences","Imad Khamis");

        cc.add(country1);
        cc.add(country2);
        cc.add(country3);
        cc.add(country4);
        cc.add(country5);
        cc.add(country6);
        cc.add(country7);
        cc.add(country8);
        cc.add(country9);
        cc.add(country10);*/

        CountryDBDao countryDBDao = new CountryDBDao(this);
        countries = countryDBDao.getCountries();
        adapter = new ProductListAdapter(countries);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
       // ProductListAdapter adapter = new ProductListAdapter(countryDBDao.getCountries());
       // recyclerView.setAdapter(adapter);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "FloatingActionButtonClicked", Toast.LENGTH_SHORT).show();
                Intent addCountryIntent = new Intent(getApplicationContext(), CountryAddActivity.class);
                startActivity(addCountryIntent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);
        MenuItem item = menu.findItem(R.id.menuSearch);
        SearchView searchView = (SearchView) item.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
              //  Toast.makeText(getApplicationContext(), "On Query Text Submit", Toast.LENGTH_SHORT).show();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String query) {
              final    List<Country> filteredList= filter(countries,query);
                adapter.setFilter(filteredList);
              //  Toast.makeText(getApplicationContext(), "On Query Text Change", Toast.LENGTH_SHORT).show();

                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);

    }


    private List<Country> filter(List<Country> countries,String query){
            List<Country> filterCountries = new ArrayList <>();
          // List <Country> countries = new CountryDao().getCountries();
            // System.out.print(countries);
            for (Country country : countries) {
                //  System.out.print(country.name);
                if (country.name.toLowerCase().contains(query.toLowerCase())) {
                    // Log.i(TAG,country.name );

                    filterCountries.add(country);
                }

            }
            for (Country country : filterCountries) {
                Log.i(TAG, country.name);
            }
            return  filterCountries;
        }



}



