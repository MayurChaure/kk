package com.example.dell.recyclerview;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

public class CountryAddActivity extends AppCompatActivity {
    EditText textView1;
    EditText textView4;
    EditText textView2;
    EditText textView3;
    ImageView imageView;
    String name, capital, pm, desc;
    int flag;
    Context context;
    private static final int REQUEST_CAMERA = 0;
    private static final int SELECT_FILE = 1;
    String userChoosenTask;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_add);
        textView1 = findViewById(R.id.editText);
        textView2 = findViewById(R.id.editText2);
        textView3 = findViewById(R.id.editText3);
        textView4 = findViewById(R.id.editText4);
        imageView = findViewById(R.id.imageView3);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImage();
            }
        });
        Button button = (Button) findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                try {
                    name = textView1.getText().toString();
                    capital = textView2.getText().toString();
                    pm = textView3.getText().toString();
                    desc = textView4.getText().toString();
                    Country country = new Country(name, capital, R.drawable.india, pm, desc);

                    new CountryDBDao(getApplicationContext()).insertCountry(country);

                    Toast.makeText(getApplicationContext(), "Country submitted successfully.", Toast.LENGTH_SHORT).show();
                    Intent MainActivity = new Intent(getApplicationContext(), com.example.dell.recyclerview.MainActivity.class);
                    startActivity(MainActivity);
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Country submissio failed. Please try again after some time.", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(CountryAddActivity.this);
        builder.setTitle("Add Photo");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if ((items[item]).equals("Take Photo")) {
                    if (ContextCompat.checkSelfPermission(CountryAddActivity.this, Manifest.permission.CAMERA)
                            !=PackageManager.PERMISSION_GRANTED) {
                        userChoosenTask = "Take photo";
                        ActivityCompat.requestPermissions(CountryAddActivity.this, new String[]{Manifest.permission.CAMERA},REQUEST_CAMERA);
                    } else {
                        cameraIntent();
                    }
                }
                 else if (items[item].equals("Choose from gallery")) {
                    if (ContextCompat.checkSelfPermission(CountryAddActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                        userChoosenTask = "Choose from gallery";
                        ActivityCompat.requestPermissions(CountryAddActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, SELECT_FILE);

                    } else {
                        galleryIntent();
                    }
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });

        builder.show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permission,int[] grantResults){
        switch (requestCode){
            case REQUEST_CAMERA:
                if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    cameraIntent();
                }else{
                    Toast.makeText(this, "plese give me camera access permission to add photo of proprty", Toast.LENGTH_SHORT).show();
                }
                break;
            case SELECT_FILE:
                if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    galleryIntent();
                }else{
                    Toast.makeText(this, "plese give gallery access permission to add photo of proprty", Toast.LENGTH_SHORT).show();
                }
                break;
        }


    }

     void cameraIntent() {
        Toast.makeText(this, "camera intent granted", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent,REQUEST_CAMERA);
    }
    void galleryIntent(){
        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");
        Intent pickIntent=new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");
        Intent chooserIntent=Intent.createChooser(getIntent,"select image");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{pickIntent});
        startActivityForResult(chooserIntent,SELECT_FILE);
        Toast.makeText(this, "gallery intent granted", Toast.LENGTH_SHORT).show();


    }
    public void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode== Activity.RESULT_OK){
            if (requestCode==SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode==REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data){
        Bitmap bitmapImage=(Bitmap) data.getExtras().get("data");
        ContextWrapper cw=new ContextWrapper(getApplicationContext());
        File directory=cw.getDir("imageDir", Context.MODE_PRIVATE);
        //Create imageDir
        Long tsLong=System.currentTimeMillis()/1000;
        String ts=tsLong.toString();
        File myPath=new File(directory,ts+".jpg");
        FileOutputStream fos=null;
        try{
            fos=new FileOutputStream(myPath);
            bitmapImage.compress(Bitmap.CompressFormat.PNG,100,fos);

        }catch(Exception e){
            e.printStackTrace();
        }finally {
            try{
                fos.close();
            }catch(Exception e1){
                e1.printStackTrace();
            }
        }
        Uri imageUri=Uri.fromFile(myPath);
        imageView.setImageBitmap(bitmapImage);
        Toast.makeText(getApplicationContext(),imageUri.getPath(),Toast.LENGTH_SHORT).show();


    }
    private void onSelectFromGalleryResult(Intent data){
        Bitmap bm=null;
        ContextWrapper cw=new ContextWrapper(getApplicationContext());
        File directory=cw.getDir("imageDir", Context.MODE_PRIVATE);
        //Create imageDir
        Long tsLong=System.currentTimeMillis()/1000;
        String ts=tsLong.toString();

        File mypath = new File(directory,ts + ".jpg");
        FileOutputStream fos = null;
        if (data!=null){
            try{
                fos = new FileOutputStream(mypath);
                bm=MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(),data.getData());
                bm.compress(Bitmap.CompressFormat.PNG,100,fos);
                imageView.setImageBitmap(bm);
                //          String filePath=saveToInternalStorage(bm);
                Uri imageUri=data.getData();
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }
}
